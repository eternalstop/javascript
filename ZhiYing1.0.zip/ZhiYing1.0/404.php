<?php get_header(); ?>
<div class="content-wrap">
	<div style="text-align:center;padding:10px 0;font-size:16px;background-color:#ffffff;">
		<h2 style="font-size:36px;margin-bottom:10px;">404！主人，我找不到路了。。。。。。</h2></div>
<?php get_footer(); ?>
