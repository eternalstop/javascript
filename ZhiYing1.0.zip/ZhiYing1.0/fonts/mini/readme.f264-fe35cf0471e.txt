  本地引用使用方法（迷你简细行楷）：
  1、下载 zip 文件并解压后，会得到1个 css 文件和扩展名分别为 .eot .woff .ttf .svg 的4个字体文件，将它们放到您网站根目录或某个资源子目录，如 css 子目录（确保这5个文件放在同一目录中）。 
  2、在您的网页源文件的 <head> 标签内，添加代码  <link href="css/www.fontorg.com.f264-fe35cf0471e.css" rel="stylesheet" type="text/css"/> 引用上述 css 文件。
  3、在该源文件的目标文字容器标签中按 style='font-family: f264-fe35cf0471e;' 或 class= 'css-f264-fe35cf0471e' 的方式使用该字体。
  免责声明：本网站提供的字体服务只用作技术展示与技术交流，各种字体未经该字体的作者授权不得用于商业目的，如有侵权行为，由用户自行承担法律责任。
  技术支持：www.fontorg.com  方拓字体
