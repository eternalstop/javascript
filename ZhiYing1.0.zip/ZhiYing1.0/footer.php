</section>
<footer class="footer">
    <div class="footer-inner">
        <div class="copyright pull-left">
         <p>Copyright © 2018-2019 <a href="http://www.zhouzying.cn" title="志颖博客"> 志颖博客 </a> All Rights Reserved  |  Powered by WordPress  |  Theme base on <a rel="nofollow" target="_blank" href="http://www.yusi123.com">Yusi</a> 备案号：<a rel="nofollow" target="_blank" href="http://www.miitbeian.gov.cn">赣ICP备18009133号</a>  |  <a href="http://www.zhouzying.cn/sitemap.xml" title="站点地图">站点地图</a></p>
        </div>
        <div class="trackcode pull-right">
            <?php if( dopt('d_track_b') ) echo dopt('d_track'); ?>
        </div>
    </div>
</footer>

<?php 
wp_footer(); 
global $dHasShare; 
if($dHasShare == true){ 
	echo'<script>with(document)0[(getElementsByTagName("head")[0]||body).appendChild(createElement("script")).src="http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion="+~(-new Date()/36e5)];</script>';
}  
if( dopt('d_footcode_b') ) echo dopt('d_footcode'); 
?>
</body>
</html>
